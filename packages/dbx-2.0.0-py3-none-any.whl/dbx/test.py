"""
  Dave Skura
  
"""

print (" Starting ") # 

import readchar
print('Reading a char:')
ch = readchar.readchar()
print(ch)
#print('Reading a key:')
#print(repr(readchar.readkey()))