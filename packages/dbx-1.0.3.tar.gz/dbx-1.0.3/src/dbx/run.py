"""
  Dave Skura, Dec,2022
"""

from dbx import help
import sys

def main():
	print('')
	print('Modules: ')
	print('1. find all schemas and count all tables ') 
	selectchar = ''
	while selectchar != 'x':
		selectchar = input('select (1): ') or 'x'
		print('')
		if selectchar.upper() == '1':
			help.show_SimpleAnalysis()

main()