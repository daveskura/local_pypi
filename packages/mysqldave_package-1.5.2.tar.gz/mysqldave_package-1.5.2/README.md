# mysqldave

A wrapper for simplified MySQL access

### install with pip
pip install mysqldave_package

### command line test
py -m mysqldave_package.mysqldave

### Quick Start Guide
https://github.com/daveskura/mysqldave/blob/main/QuickStart.md

### Methods
https://github.com/daveskura/mysqldave/blob/main/methods.md
