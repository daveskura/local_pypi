/*
  -- Dave Skura, 2022
*/

SELECT current_timestamp;