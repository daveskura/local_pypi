/*
  -- Dave Skura, 2022
*/

SELECT CURRENT_DATE;